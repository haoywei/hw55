/*
 * Copyright (c) 2016 Google, Inc
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __SANDBOX_SPL_CONFIG_H
#define __SANDBOX_SPL_CONFIG_H

#include <configs/sandbox.h>

#define CONFIG_SPL_FRAMEWORK

#endif
