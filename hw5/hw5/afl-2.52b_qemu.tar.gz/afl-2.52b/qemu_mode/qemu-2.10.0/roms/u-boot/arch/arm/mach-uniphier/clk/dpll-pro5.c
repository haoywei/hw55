#include "../init.h"

int uniphier_pro5_dpll_init(const struct uniphier_board_data *bd)
{
	return 0;
}
