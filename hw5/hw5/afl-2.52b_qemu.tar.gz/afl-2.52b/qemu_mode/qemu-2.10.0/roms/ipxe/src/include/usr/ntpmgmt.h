#ifndef _USR_NTPMGMT_H
#define _USR_NTPMGMT_H

/** @file
 *
 * NTP management
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern int ntp ( const char *hostname );

#endif /* _USR_NTPMGMT_H */
