#ifndef _IPXE_STRING_H
#define _IPXE_STRING_H

/** @file
 *
 * String functions
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern unsigned int digit_value ( unsigned int digit );

#endif /* _IPXE_STRING_H */
