void relocate(struct sys_info *);
