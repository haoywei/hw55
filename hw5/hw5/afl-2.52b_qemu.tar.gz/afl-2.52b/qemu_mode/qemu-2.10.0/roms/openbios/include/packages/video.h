#ifndef VIDEO_SUBR_H
#define VIDEO_SUBR_H

/* packages/video.c */
void molvideo_init(void);

#endif /* VIDEO_SUBR_H */
