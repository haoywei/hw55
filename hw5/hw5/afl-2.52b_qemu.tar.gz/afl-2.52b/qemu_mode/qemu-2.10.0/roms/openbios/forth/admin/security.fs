\ 7.4.6    Security

: password    ( -- )
  ;

: security-password ( -- password-str password-len )
  ;
  
: security-#badlogins    ( -- n )
  ;
